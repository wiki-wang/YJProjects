MgrLoginUrl  =      'http://localhost/mgr/login/login.html'
StudentLoginUrl=    'http://localhost/student/login/login.html'

database=           ['127.0.0.1'  , '3306']
adminuser=          {'name':'auto'  ,  'pw':'sdfsdfsdf'}


g_vcode = '00000003175489158301'
g_subject_math_id = 1
g_subject_science_id = 5
g_grade_7_id = 1
g_teacher_login_url = 'http://ci.ytesting.com/teacher/login/login.html'