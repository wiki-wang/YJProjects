import requests
from cfg import g_vcode
# from spj01.spj.cfg import g_vcode
from pprint import pprint
from robot.libraries.BuiltIn import BuiltIn


class StudentLib:
    URL = "http://ci.ytesting.com/api/3school/students"

    def __init__(self):
        self.vcode = g_vcode

    def set_vcode(self,vcode):
        self.vcode = vcode


    def delete_student(self,studentid):
        payload = {
            'vcode'  : self.vcode,
        }

        url = '{}/{}'.format(self.URL,studentid)
        response = requests.delete(url,data=payload)

        bodyDict = response.json()
        pprint(bodyDict, indent=2)

        return bodyDict


    def list_student(self):

        params = {
            'vcode': self.vcode,
            'action': 'search_with_pagenation'
        }

        response = requests.get(self.URL,params=params)

        bodyDict = response.json()
        pprint (bodyDict,indent=2)
        return bodyDict


    def add_student(self,username, realname, gradeid, classid, phonenumber, idSavedName=None):

        payload = {
            'vcode'  : self.vcode,
            'action' : 'add',
            'username':username,
            'realname': realname,
            'gradeid':int(gradeid),
            'classid':classid,
            'phonenumber':phonenumber
        }

        pprint(payload)
        response = requests.post(self.URL,data=payload)
        pprint (response,indent=2)
        bodyDict = response.json()
        pprint (bodyDict,indent=2)

        if idSavedName:
            print('before:')
            BuiltIn().set_global_variable('${%s}' % idSavedName, bodyDict['id'])
            print(f"global var set: ${idSavedName}:{bodyDict['id']}")

        return bodyDict


    def modify_student(self,studentid, realname=None, phonenumber=None):
        url = self.URL+f'/{studentid}'
        payload = {
            'vcode'  : self.vcode,
            'action' : 'modify'
        }
        if realname != None:
            payload['realname']=realname

        if phonenumber != None:
            payload['phonenumber'] = phonenumber

        response = requests.put(url,data=payload)

        bodyDict = response.json()
        pprint (bodyDict,indent=2)
        return bodyDict


    def delete_all_students(self):
        # 先列出所有学生
        rd =  self.list_student()
        pprint(rd, indent=2)

        # 删除列出的所有学生
        for one in rd['retlist']:
            self.delete_student(one['id'])

        #再列出所有学生
        rd =  self.list_student()
        pprint (rd,indent=2)

        # 如果没有删除干净，通过异常报错给RF
        # 参考http://robotframework.org/robotframework/latest/RobotFrameworkUserGuide.html#reporting-keyword-status
        if rd['retlist'] != []:
            raise  Exception("cannot delete all students!!")


    def studentList_should_contain(self, studentList, classid, username, realname,
                                   phonenumber, stuid, expectedTimes = 1):
        item = {
            "classid": int(classid),
            "username": username,
            "realname": realname,
            "phonenumber": phonenumber,
            "id": int(stuid)
        }

        pprint(item)

        occurTimes = studentList.count(item)

        assert occurTimes == expectedTimes, f'学生列表包含了{occurTimes}次指定信息，期望包含{expectedTimes}次！！'








if __name__ == '__main__':
    scm = StudentLib()
    scm.list_student()
    scm.delete_all_students()


