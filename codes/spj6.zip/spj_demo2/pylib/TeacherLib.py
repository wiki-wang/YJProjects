import requests
from cfg import g_vcode
# from spj01.spj.cfg import g_vcode
from pprint import pprint
import json
from robot.libraries.BuiltIn import BuiltIn


class TeacherLib:
    URL = "http://ci.ytesting.com/api/3school/teachers"

    def __init__(self):
        self.vcode = g_vcode

    def set_vcode(self,vcode):
        self.vcode = vcode


    def delete_teacher(self,teacherid):
        payload = {
            'vcode'  : self.vcode,
        }

        url = '{}/{}'.format(self.URL,teacherid)
        response = requests.delete(url,data=payload)

        bodyDict = response.json()
        pprint(bodyDict, indent=2)

        return bodyDict


    def list_teacher(self,subjectid=None):

        params = {
            'vcode': self.vcode,
            'action': 'search_with_pagenation'
        }

        if subjectid != None:
            params['subjectid']:int(subjectid)

        response = requests.get(self.URL,params=params)

        bodyDict = response.json()
        pprint (bodyDict,indent=2)
        return bodyDict


    def add_teacher(self,username, realname, subjectid, classlist,
                    phonenumber, email, idcardnumber, idSavedName=None):

        # 230,231,232
        tmpList = str(classlist).split(',')
        newclasslist = [{'id':one.strip()} for one in tmpList if one]

        payload = {
            'vcode'  : self.vcode,
            'action' : 'add',
            'username':username,
            'realname': realname,
            'subjectid':int(subjectid),
            'classlist':json.dumps(newclasslist),
            'phonenumber':phonenumber,
            'email':email,
            'idcardnumber':idcardnumber
        }

        pprint(payload)
        response = requests.post(self.URL,data=payload)
        pprint (response,indent=2)
        bodyDict = response.json()
        pprint (bodyDict,indent=2)

        if idSavedName:
            print('before:')
            BuiltIn().set_global_variable('${%s}' % idSavedName, bodyDict['id'])
            print(f"global var set: ${idSavedName}:{bodyDict['id']}")

        return bodyDict


    def modify_teacher(self,teacherid, realname=None, subjectid=None,
                            classlist=None, phonenumber=None, email=None, idcardnumber=None):
        url = self.URL+f'/{teacherid}'
        payload = {
            'vcode'  : self.vcode,
            'action' : 'modify'
        }
        if realname != None:
            payload['realname']=realname
        if subjectid != None:
            payload['subjectid'] = subjectid

        if classlist is not None:
            # 230,231,232
            tmpList = str(classlist).split(',')
            newclasslist = [{'id': one.strip()} for one in tmpList if one]
            payload['classlist'] = json.dumps(newclasslist)

        if phonenumber != None:
            payload['phonenumber'] = phonenumber
        if email != None:
            payload['email'] = email
        if idcardnumber != None:
            payload['idcardnumber'] = idcardnumber

        response = requests.put(url,data=payload)

        bodyDict = response.json()
        pprint (bodyDict,indent=2)
        return bodyDict


    def delete_all_teachers(self):
        # 先列出所有老师
        rd =  self.list_teacher()
        pprint(rd, indent=2)

        # 删除列出的所有老师
        for one in rd['retlist']:
            self.delete_teacher(one['id'])

        #再列出所有老师
        rd =  self.list_teacher()
        pprint (rd,indent=2)

        # 如果没有删除干净，通过异常报错给RF
        # 参考http://robotframework.org/robotframework/latest/RobotFrameworkUserGuide.html#reporting-keyword-status
        if rd['retlist'] != []:
            raise  Exception("cannot delete all teachers!!")



    def teacherList_should_contain(self,
                                   teacherList,
                                   username,
                                   teachclasslist,
                                   realname,
                                   teacherid,
                                   phonenumber,
                                   email,
                                   idcardnumber,
                                   expectedTimes = 1):

        teachclasslist = str(teachclasslist).split(',')
        # 把json格式的班级列表转换成[230,231]格式


        item = {
            "username": username,
            "teachclasslist": [int(one.strip()) for one in teachclasslist if one.strip()],
            "realname": realname,
            "id": int(teacherid),
            "phonenumber": phonenumber,
            "email": email,
            "idcardnumber": idcardnumber
            }

        occurTimes = teacherList.count(item)

        assert occurTimes == expectedTimes, f'老师列表包含了{occurTimes}次指定信息，期望包含{expectedTimes}次！！'




if __name__ == '__main__':
    scm = TeacherLib()
    # scm.delete_all_school_classes()
    # scm.add_school_class(1,'3班',60)
    # scm.modify_school_class(77572, '4班',60)
    scm.list_teacher()

    # ret = scm.add_school_class(1,'新测试',77)
    # print(json.dumps(ret, indent=2))
    #
    # ret = scm.delete_school_class(28)
    # print(json.dumps(ret, indent=2))
    #
    # ret = scm.list_school_class(1)
    # print(json.dumps(ret, indent=2))
    # #
    # scm.delete_all_school_classes()

