from selenium import webdriver
from cfg import *
import time


class SharedWebDriver:
    ROBOT_LIBRARY_SCOPE = 'GLOBAL'
    shared_wd = None

    def open_browser(self):
        SharedWebDriver.shared_wd = webdriver.Chrome()
        SharedWebDriver.shared_wd.implicitly_wait(10)

    def close_browser(self):
        SharedWebDriver.shared_wd.quit()


class TeacherWebLib:
#    ROBOT_LIBRARY_SCOPE = 'GLOBAL'
    def __init__(self):
        self.wd = SharedWebDriver.shared_wd

# 老师登录
    def teacher_Login(self, username, password='888888'):


        self.wd.get(g_teacher_login_url)
        self.wd.find_element_by_id('username').send_keys(username)
        self.wd.find_element_by_id('password').send_keys(password)
        self.wd.find_element_by_id('submit').click()

# 检查 学校、姓名、学科、金币、已发布微课、已发布作业 信息是否正确
    def get_teacher_homepage_info(self):
        # time.sleep(3)
        self.wd.find_element_by_css_selector("a[href='#/home']>li").click()
        time.sleep(3)

        eles = self.wd.find_elements_by_css_selector('.ng-binding')
        retList = [ele.text for ele in eles]
        print(retList)

        return retList

# 检查学生列表
    def get_teacher_class_students_info(self):

        self.wd.find_element_by_css_selector("div.main-menu li:nth-of-type(4)>a").click()
        self.wd.find_element_by_css_selector("a[href*='student_group'] span").click()

        time.sleep(3)

        # 获取年级班级
        classDivs = self.wd.find_elements_by_css_selector(
            '.panel-green'
        )

        retTable = {}

        # 构造{'班级':[学生1，学生2]}作为返回值
        for classDiv in classDivs:
            className = classDiv.find_element_by_class_name(
                'panel-heading'
            ).text.replace(' ','')

            classDiv.click()

            time.sleep(2)
            self.wd.implicitly_wait(1)

            eles = classDiv.find_elements_by_css_selector(
                'tbody tr td:nth-child(2)'
            )
            self.wd.implicitly_wait(10)

            studentNames = [ele.text for ele in eles]
            retTable[className] = studentNames

            print(retTable)

        return retTable



    def teacherLogout(self):
        self.driver.find_element_by_css_selector('a.dropdown-toggle>span.ng-binding').click()
        self.driver.find_element_by_css_selector('a[ng-click = "logout()"]').click()



if __name__ == '__main__':
    SharedWebDriver().open_browser()

    webop = TeacherWebLib()
    webop.teacher_Login('wyy','888888')
    webop.get_teacher_homepage_info()
    webop.get_teacher_class_students_info()








