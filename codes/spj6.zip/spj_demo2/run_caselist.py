import os

with open('tclist.txt') as fo:
    readStr = fo.read()
    tcList = [one.strip() for one in readStr.split(' | ') if one]

# 把用例编号拼接成字符串，符合robot参数格式
writeStr = []
for one in tcList:
    writeStr.append('--test *' + one)
writeStr = '\n'.join(writeStr)

# 构建RobotFramework的参数

args = '''
--pythonpath .
{}
tc
'''.format(writeStr)

# robot命令写入参数
with open('argfile','w') as fo:
    fo.write(args)

ret = os.system('robot -A argfile')

if ret == 0:
    print('自动化执行成功！')
else:
    print('自动化执行失败！返回码:{}'.format(ret))

